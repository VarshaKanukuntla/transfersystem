CREATE TABLE IF NOT EXISTS accounts (
    account_id INT PRIMARY KEY,
    balance NUMERIC(20, 5) NOT NULL CHECK (balance >= 0)
);
