package handler

import (
	"encoding/json"
	"net/http"
	"strconv"

	"transfersystem/db"
	"transfersystem/model"

	"github.com/gorilla/mux"
)

func CreateAccount(w http.ResponseWriter, r *http.Request) {
	var acc model.Account
	if err := json.NewDecoder(r.Body).Decode(&acc); err != nil {
		http.Error(w, "Invalid input", http.StatusBadRequest)
		return
	}
	_, err := db.DB.Exec("INSERT INTO accounts (account_id, balance) VALUES ($1, $2)", acc.AccountID, acc.Balance)
	if err != nil {
		http.Error(w, "Account creation failed", http.StatusInternalServerError)
		return
	}
	w.WriteHeader(http.StatusCreated)
}

func GetAccount(w http.ResponseWriter, r *http.Request) {
	idStr := mux.Vars(r)["id"]
	id, err := strconv.Atoi(idStr)
	if err != nil {
		http.Error(w, "Invalid account ID", http.StatusBadRequest)
		return
	}
	var acc model.Account
	err = db.DB.Get(&acc, "SELECT account_id, balance FROM accounts WHERE account_id=$1", id)
	if err != nil {
		http.Error(w, "Account not found", http.StatusNotFound)
		return
	}
	json.NewEncoder(w).Encode(acc)
}

func CreateTransaction(w http.ResponseWriter, r *http.Request) {
	var tx model.TransactionRequest
	if err := json.NewDecoder(r.Body).Decode(&tx); err != nil {
		http.Error(w, "Invalid input", http.StatusBadRequest)
		return
	}

	txCtx, err := db.DB.Beginx()
	if err != nil {
		http.Error(w, "Transaction start error", http.StatusInternalServerError)
		return
	}
	defer txCtx.Rollback()

	var sourceBalance float64
	err = txCtx.Get(&sourceBalance, "SELECT balance FROM accounts WHERE account_id=$1 FOR UPDATE", tx.SourceAccountID)
	if err != nil {
		http.Error(w, "Source account not found", http.StatusNotFound)
		return
	}

	if sourceBalance < tx.Amount {
		http.Error(w, "Insufficient funds", http.StatusBadRequest)
		return
	}

	_, err = txCtx.Exec("UPDATE accounts SET balance = balance - $1 WHERE account_id = $2", tx.Amount, tx.SourceAccountID)
	if err != nil {
		http.Error(w, "Debit failed", http.StatusInternalServerError)
		return
	}

	_, err = txCtx.Exec("UPDATE accounts SET balance = balance + $1 WHERE account_id = $2", tx.Amount, tx.DestinationAccountID)
	if err != nil {
		http.Error(w, "Credit failed", http.StatusInternalServerError)
		return
	}

	if err := txCtx.Commit(); err != nil {
		http.Error(w, "Transaction commit failed", http.StatusInternalServerError)
		return
	}

	w.WriteHeader(http.StatusOK)
}
