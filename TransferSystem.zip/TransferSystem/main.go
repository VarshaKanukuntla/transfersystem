package main

import (
	"log"
	"net/http"

	"transfersystem/db"
	"transfersystem/handler"

	"github.com/gorilla/mux"
)

func main() {
	db.Init()

	r := mux.NewRouter()
	r.HandleFunc("/accounts", handler.CreateAccount).Methods("POST")
	r.HandleFunc("/accounts/{id}", handler.GetAccount).Methods("GET")
	r.HandleFunc("/transactions", handler.CreateTransaction).Methods("POST")

	log.Println("Server running on :8080")
	log.Fatal(http.ListenAndServe(":8080", r))
}
